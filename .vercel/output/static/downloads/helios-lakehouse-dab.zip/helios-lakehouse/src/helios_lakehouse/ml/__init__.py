# training, evaluation, registry, inference
