# bronze streaming tables
